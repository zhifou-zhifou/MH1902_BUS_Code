#ifndef _BKP_H
#define _BKP_H


void writeBPK(unsigned char index,unsigned int dat);
unsigned int readBPK(unsigned char index);







#endif



